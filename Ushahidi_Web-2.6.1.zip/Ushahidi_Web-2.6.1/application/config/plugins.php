<?php defined('SYSPATH') or die('No direct script access allowed.');
/**
 * Plugins Configuration
 *
 * This file contains configuration options for plugins
 *
 */

// This setting will hide plugins from the plugin list in the admin panel.
//   Must be an array of the dir names of the plugins you want to hide.
//   i.e. 'smssync','viddler', etc...
$config['hide_from_list'] = array();

// TODO: Add other config options like "force enable", "force disable", etc.