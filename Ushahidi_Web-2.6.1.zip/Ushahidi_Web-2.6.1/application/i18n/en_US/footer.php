<?php
$lang = array(
	'cURL_not_installed' => 'php5-curl is not installed on this system.',
);
?>
