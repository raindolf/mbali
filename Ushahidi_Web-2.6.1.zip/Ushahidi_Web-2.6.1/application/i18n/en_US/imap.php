<?php
$lang = array(
	'imap_stream_not_opened' => 'Could not open IMAP stream.',
	'unsupported_service' => 'The email service is not supported.',
);
?>
